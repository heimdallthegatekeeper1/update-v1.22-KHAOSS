"""
Minimal local voice server for Hermes/AionUi (KHAOSS Voicebox pilot).

Local-only — TTS via piper, STT via whisper.cpp. NO cloud, privacy-first.
OPT-IN: nothing starts this server automatically.

Endpoints:
  GET  /health     -> TTS + STT + cloning status
  GET  /voices     -> {voices: [{name, path, default}]}      installed piper voices
  GET  /devices    -> {devices: [{id, label, default}]}      aplay output devices
  POST /speak      {"text","output"?,"play"?,"voice"?,"device"?,"volume"?,"speed"?}
                   voice may be "clone:<name>" to use a cloned voice (XTTS, opt-in)
  POST /test       {"voice"?,"device"?,"volume"?,"speed"?}   speak a fixed sample now
  POST /transcribe (raw audio bytes in body) -> {ok, text}   local speech-to-text
  POST /voice/clone?name=<name>  (raw reference audio bytes) -> {ok, name}   register clone
  GET  /clones     -> {clones: [{name, ref, created}]}       cloned voices
"""
import array
import asyncio
import json
import os
import subprocess
import sys
import threading
import time
import wave
import pathlib
import tempfile
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn

app = FastAPI(title="KHAOSS Voicebox", version="0.5.0")

# The AionUi renderer (Electron, file://-origin) calls /speak via fetch. Without CORS
# the browser blocks the cross-origin POST. The server binds 127.0.0.1 only, so
# allowing all origins here is local-loopback-only.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

PIPER_DIR = pathlib.Path.home() / ".local/share/piper"
DEFAULT_VOICE = "en_US-lessac-medium"
SAMPLE_TEXT = "KHAOSS voice check. If you can hear this, the voice path is working."

# STT (local whisper.cpp — no cloud). Override via env if relocated.
WHISPER_CLI = pathlib.Path(os.environ.get("KHAOSS_WHISPER_CLI", str(pathlib.Path.home() / "whisper.cpp/build/bin/whisper-cli")))
WHISPER_MODEL = pathlib.Path(os.environ.get("KHAOSS_WHISPER_MODEL", str(pathlib.Path.home() / ".local/share/whisper/ggml-tiny.bin")))


def stt_available() -> bool:
    return WHISPER_CLI.exists() and WHISPER_MODEL.exists()


# ---------------------------------------------------------------------------
# Voice cloning (XTTS-v2, on-box, OPT-IN, off-by-default)
#
# The heavy model (torch + coqui-tts, ~1.8GB) lives in a dedicated venv so it never
# pollutes the piper path. We talk to clone_worker.py (running in that venv) over a
# long-lived stdin/stdout subprocess. The worker is spawned LAZILY on first clone
# synthesis — startup and every piper call stay completely unaffected.
# ---------------------------------------------------------------------------
HERE = pathlib.Path(__file__).resolve().parent
CLONE_VENV_PY = HERE / "clone_env" / "bin" / "python"
CLONE_WORKER = HERE / "clone_worker.py"
CLONES_DIR = HERE / "clones"          # reference wavs: <name>.wav  (= the clone registry)
CLONES_DIR.mkdir(exist_ok=True)

_clone_proc = None                    # the warm worker subprocess (None until first use)
_clone_lock = threading.Lock()        # serialize access — one CPU model, one request at a time


def cloning_available() -> bool:
    """True if the clone venv + worker are installed (model loads lazily on first use)."""
    return CLONE_VENV_PY.exists() and CLONE_WORKER.exists()


def list_clones():
    clones = []
    for ref in sorted(CLONES_DIR.glob("*.wav")):
        clones.append({
            "name": ref.stem,
            "ref": str(ref),
            "created": int(ref.stat().st_mtime),
        })
    return clones


def _ensure_worker():
    """Spawn the XTTS worker subprocess if not already running. Caller holds _clone_lock."""
    global _clone_proc
    if _clone_proc is not None and _clone_proc.poll() is None:
        return _clone_proc
    if not cloning_available():
        raise RuntimeError("cloning not installed (clone_env venv or worker missing)")
    _clone_proc = subprocess.Popen(
        [str(CLONE_VENV_PY), str(CLONE_WORKER)],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        cwd=str(HERE),
        bufsize=1,
        text=True,
    )
    # Drain the "started" banner so the first real request reads its own response.
    line = _clone_proc.stdout.readline()
    if not line:
        _clone_proc = None
        raise RuntimeError("clone worker failed to start")
    return _clone_proc


def _clone_rpc(req: dict, read_timeout: float = 180.0) -> dict:
    """Send one request to the warm worker and read one response. Serialized by _clone_lock."""
    with _clone_lock:
        proc = _ensure_worker()
        try:
            proc.stdin.write(json.dumps(req) + "\n")
            proc.stdin.flush()
        except (BrokenPipeError, OSError):
            # Worker died — drop it so the next call respawns.
            globals()["_clone_proc"] = None
            return {"ok": False, "error": "clone worker pipe broken (respawn on next call)"}
        # The worker has no internal timeout; readline blocks until it answers. The
        # first synth pays the one-time model-load (~11s) + synth (~18s/sentence).
        line = proc.stdout.readline()
        if not line:
            globals()["_clone_proc"] = None
            return {"ok": False, "error": "clone worker closed unexpectedly"}
        try:
            return json.loads(line)
        except json.JSONDecodeError:
            return {"ok": False, "error": "bad worker response: " + line[:200]}


def _clone_ref_path(name: str) -> pathlib.Path:
    safe = "".join(c for c in name if c.isalnum() or c in ("-", "_")).strip() or "clone"
    return CLONES_DIR / f"{safe}.wav"


def _run_transcription(audio: bytes) -> dict:
    """Blocking: write audio → ffmpeg to 16 kHz mono WAV → whisper.cpp → transcript.
    Bounded by subprocess timeouts so it can never hang indefinitely."""
    raw = tempfile.mktemp(suffix=".webm")
    wav = tempfile.mktemp(suffix=".wav")
    try:
        with open(raw, "wb") as f:
            f.write(audio)
        conv = subprocess.run(
            ["ffmpeg", "-y", "-i", raw, "-ar", "16000", "-ac", "1", wav],
            capture_output=True,
            timeout=30,
        )
        if conv.returncode != 0 or not os.path.exists(wav):
            return {"ok": False, "error": "audio decode failed: " + conv.stderr.decode()[:200]}
        res = subprocess.run(
            [str(WHISPER_CLI), "-m", str(WHISPER_MODEL), "-f", wav, "-nt", "-l", "en"],
            capture_output=True,
            timeout=60,
        )
        if res.returncode != 0:
            return {"ok": False, "error": "transcription failed: " + res.stderr.decode()[:200]}
        text = res.stdout.decode().strip()
        # whisper.cpp emits non-speech MARKERS on silent/unclear input, e.g. [BLANK_AUDIO],
        # [inaudible], [silence], (silence), [ Music ], [no audio]. Any transcript that is
        # ENTIRELY a single bracketed/parenthesised marker = no real speech → return empty so
        # the UI shows "no speech detected" instead of inserting "[inaudible]".
        import re as _re
        stripped = text.strip()
        is_marker = bool(_re.fullmatch(r"[\[\(].*?[\]\)]", stripped)) or stripped.lower() in (
            "[blank_audio]", "(silence)", "[silence]", "[inaudible]", "[ silence ]", "[no audio]", "you")
        if not stripped or is_marker:
            return {"ok": True, "text": "", "note": "no speech detected"}
        return {"ok": True, "text": stripped}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "STT timed out (audio too long or engine stalled)"}
    finally:
        for tmp in (raw, wav):
            try:
                os.remove(tmp)
            except OSError:
                pass


def voice_path(voice: str) -> pathlib.Path:
    """Resolve a voice name (e.g. 'en_US-amy-medium') to its .onnx path."""
    name = voice if voice.endswith(".onnx") else f"{voice}.onnx"
    return PIPER_DIR / name


def list_voices():
    voices = []
    for onnx in sorted(PIPER_DIR.glob("*.onnx")):
        name = onnx.stem
        voices.append({"name": name, "path": str(onnx), "default": name == DEFAULT_VOICE})
    return voices


def list_devices():
    """Enumerate ALSA output devices via `aplay -l`, plus the named 'default'/'pulse' PCMs."""
    devices = [{"id": "default", "label": "System default", "default": True}]
    try:
        out = subprocess.run(["aplay", "-l"], capture_output=True, timeout=5).stdout.decode()
        for line in out.splitlines():
            # "card 0: sofhdadsp [sof-hda-dsp], device 0: HDA Analog (*) []"
            if line.startswith("card "):
                try:
                    card = line.split("card ")[1].split(":")[0].strip()
                    dev = line.split("device ")[1].split(":")[0].strip()
                    desc = line.split("device ")[1].split(":", 1)[1].strip()
                    devices.append({
                        "id": f"plughw:{card},{dev}",
                        "label": desc,
                        "default": False,
                    })
                except (IndexError, ValueError):
                    continue
    except (subprocess.SubprocessError, FileNotFoundError):
        pass
    return devices


def apply_volume(wav_path: str, volume: float) -> str:
    """Scale 16-bit PCM WAV amplitude by `volume` (0.0–2.0). Returns a path to play.
    Volume 1.0 (or invalid) returns the original path untouched."""
    if volume is None or abs(volume - 1.0) < 0.01:
        return wav_path
    vol = max(0.0, min(2.0, float(volume)))
    try:
        with wave.open(wav_path, "rb") as w:
            params = w.getparams()
            frames = w.readframes(w.getnframes())
        if params.sampwidth != 2:
            return wav_path  # only scale 16-bit PCM
        samples = array.array("h")
        samples.frombytes(frames)
        for i in range(len(samples)):
            v = int(samples[i] * vol)
            samples[i] = max(-32768, min(32767, v))
        scaled = tempfile.mktemp(suffix=".wav")
        with wave.open(scaled, "wb") as w:
            w.setparams(params)
            w.writeframes(samples.tobytes())
        return scaled
    except (wave.Error, OSError, ValueError):
        return wav_path


class SpeakRequest(BaseModel):
    text: str
    output: str = "/tmp/khaoss_speech.wav"
    play: bool = False
    voice: str | None = None
    device: str | None = None
    volume: float | None = None
    speed: float | None = None   # piper: maps to length_scale; XTTS: speed multiplier


class TestRequest(BaseModel):
    voice: str | None = None
    device: str | None = None
    volume: float | None = None
    speed: float | None = None


_last_aplay = {"proc": None}
_aplay_lock = threading.Lock()


def _play_wav(output: str, play: bool, device, volume):
    """Shared playback helper: optional volume scale + aplay to the chosen device.

    KHAOSS-PATCH: voice-conversation — fix the "Also K" truncation. A new response must
    INTERRUPT the previous spoken one cleanly, not overlap or corrupt a shared file. We
    terminate any in-flight aplay before starting a new one. (Per-speak unique output files
    are assigned in the /speak handler so a re-synthesis never overwrites a wav mid-playback.)
    """
    if not play:
        return
    play_path = apply_volume(output, volume) if volume is not None else output
    cmd = ["aplay"]
    if device and device != "default":
        cmd += ["-D", device]
    cmd.append(play_path)
    with _aplay_lock:
        prev = _last_aplay.get("proc")
        if prev is not None and prev.poll() is None:
            try:
                prev.terminate()
            except Exception:
                pass
        _last_aplay["proc"] = subprocess.Popen(cmd)


def _stop_playback() -> bool:
    """KHAOSS-PATCH: stop-voice — terminate the current in-flight aplay immediately (halt a read
    mid-stream). Returns True if something was actually playing and got stopped."""
    with _aplay_lock:
        prev = _last_aplay.get("proc")
        if prev is not None and prev.poll() is None:
            try:
                prev.terminate()
            except Exception:
                try:
                    prev.kill()
                except Exception:
                    pass
            _last_aplay["proc"] = None
            return True
    return False


def _is_playing() -> bool:
    """KHAOSS-PATCH: stop-voice — True while a read is actively playing (drives the glowing STOP)."""
    with _aplay_lock:
        prev = _last_aplay.get("proc")
        return prev is not None and prev.poll() is None


def _synth_clone(text, output, play, voice, device, volume, speed):
    """Synthesize via XTTS using a saved reference. voice = 'clone:<name>'."""
    name = voice.split("clone:", 1)[1].strip()
    ref = _clone_ref_path(name)
    if not ref.exists():
        return {"ok": False, "error": f"clone not found: {name}", "voice": voice,
                "available": [c["name"] for c in list_clones()]}
    resp = _clone_rpc({
        "cmd": "synth", "ref": str(ref), "text": text,
        "out": output, "language": "en",
        # XTTS speed is a direct multiplier (higher = faster), opposite of piper length_scale.
        "speed": speed if speed is not None else None,
    })
    if not resp.get("ok"):
        return {"ok": False, "error": resp.get("error", "clone synth failed"), "voice": voice}
    _play_wav(output, play, device, volume)
    return {"ok": True, "output": output, "chars": len(text), "voice": voice,
            "engine": "xtts", "synth_secs": resp.get("secs"),
            "device": device or "default", "volume": volume if volume is not None else 1.0,
            "speed": speed if speed is not None else 1.0}


def _synthesize_and_play(text: str, output: str, play: bool, voice, device, volume, speed=None):
    # Cloned voices route to the XTTS worker (opt-in path).
    if voice and voice.startswith("clone:"):
        return _synth_clone(text, output, play, voice, device, volume, speed)
    model = voice_path(voice) if voice else voice_path(DEFAULT_VOICE)
    if not model.exists():
        return {"ok": False, "error": f"voice not found: {model.name}", "voice": model.stem}
    # Invoke piper-tts via `python -m piper` (the pip TTS package), NOT the bare
    # `piper` on PATH which is the unrelated GTK device-config GUI.
    cmd = [sys.executable, "-m", "piper", "-m", str(model), "-f", output]
    # piper length_scale: >1.0 = slower, <1.0 = faster. Expose an intuitive `speed`
    # multiplier (2.0 = twice as fast) and invert it into length_scale.
    if speed is not None:
        try:
            s = max(0.25, min(4.0, float(speed)))
            cmd += ["--length-scale", str(round(1.0 / s, 4))]
        except (TypeError, ValueError):
            pass
    result = subprocess.run(
        cmd,
        input=text.encode(),
        capture_output=True,
        timeout=30,
    )
    if result.returncode != 0:
        return {"ok": False, "error": result.stderr.decode()[:300], "voice": model.stem}
    _play_wav(output, play, device, volume)
    return {"ok": True, "output": output, "chars": len(text), "voice": model.stem,
            "engine": "piper", "device": device or "default",
            "volume": volume if volume is not None else 1.0,
            "speed": speed if speed is not None else 1.0}


@app.post("/speak")
async def speak(req: SpeakRequest):
    try:
        # KHAOSS-PATCH: alsok-realflow — log EVERY /speak so we can see the real agent-turn flow:
        # how many calls fire, with what text. Appended to /tmp/khaoss_speak.log.
        try:
            t = req.text or ""
            with open("/tmp/khaoss_speak.log", "a") as _lf:
                _lf.write(
                    "%.3f len=%d play=%s voice=%s | HEAD=%r | TAIL=%r\n"
                    % (time.time(), len(t), req.play, req.voice, t[:80], t[-40:])
                )
        except Exception:
            pass
        # When the caller didn't pick a specific output path (the common case: the renderer just
        # sends {text, play}), synthesize to a UNIQUE temp file so a second response can't overwrite
        # the wav mid-playback. Combined with interrupt-prior-aplay in _play_wav.
        output = req.output
        if output == "/tmp/khaoss_speech.wav":
            output = tempfile.mktemp(suffix=".wav", prefix="khaoss_speak_")
        # Run blocking piper/aplay off the event loop so a TTS call can't freeze
        # concurrent /transcribe requests (root cause of the live transcribe-hang).
        return await asyncio.to_thread(
            _synthesize_and_play, req.text, output, req.play, req.voice,
            req.device, req.volume, req.speed
        )
    except Exception as e:  # noqa: BLE001 - surface any failure to the caller
        return {"ok": False, "error": str(e)}


@app.post("/stop")
async def stop():
    """KHAOSS-PATCH: stop-voice — halt the current read mid-stream. Terminates the in-flight aplay."""
    stopped = await asyncio.to_thread(_stop_playback)
    return {"ok": True, "stopped": stopped}


@app.get("/status")
async def status():
    """KHAOSS-PATCH: stop-voice — is a read playing right now? Drives the glowing STOP button."""
    return {"ok": True, "playing": _is_playing()}


@app.post("/test")
async def test(req: TestRequest):
    """Speak a fixed sample immediately — for the UI 'Test' button."""
    try:
        return await asyncio.to_thread(
            _synthesize_and_play, SAMPLE_TEXT, "/tmp/khaoss_test.wav", True,
            req.voice, req.device, req.volume, req.speed
        )
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": str(e)}


@app.get("/voices")
async def voices():
    return {"voices": list_voices()}


@app.get("/devices")
async def devices():
    return {"devices": list_devices()}


@app.post("/transcribe")
async def transcribe(request: Request):
    """Local speech-to-text. Body = raw audio bytes (webm/ogg/wav from the browser
    MediaRecorder). Converts to 16 kHz mono WAV via ffmpeg, runs whisper.cpp, returns
    {ok, text}. No cloud. Visible errors — never a silent empty result."""
    if not stt_available():
        missing = "whisper-cli binary" if not WHISPER_CLI.exists() else "whisper model"
        return {"ok": False, "error": f"STT not available: {missing} missing. Place a ggml model at {WHISPER_MODEL}."}
    try:
        audio = await request.body()
        if not audio:
            return {"ok": False, "error": "no audio received"}
        # Run the blocking ffmpeg + whisper.cpp work off the event loop so it can't
        # freeze concurrent requests and hang the client (the live spinner bug).
        return await asyncio.to_thread(_run_transcription, audio)
    except Exception as e:  # noqa: BLE001 - surface any failure to the caller
        return {"ok": False, "error": str(e)}


def _register_clone(name: str, audio: bytes) -> dict:
    """Blocking: decode the reference audio to 22.05 kHz mono WAV and save it as the
    clone registry entry. XTTS clones zero-shot from this single reference sample."""
    ref = _clone_ref_path(name)
    raw = tempfile.mktemp(suffix=".bin")
    try:
        with open(raw, "wb") as f:
            f.write(audio)
        conv = subprocess.run(
            ["ffmpeg", "-y", "-i", raw, "-ar", "22050", "-ac", "1", str(ref)],
            capture_output=True,
            timeout=30,
        )
        if conv.returncode != 0 or not ref.exists():
            return {"ok": False, "error": "reference decode failed: " + conv.stderr.decode()[:200]}
        # Guard against trivially short references (XTTS wants ~3s+).
        try:
            with wave.open(str(ref), "rb") as w:
                dur = w.getnframes() / float(w.getframerate() or 1)
        except wave.Error:
            dur = 0.0
        return {"ok": True, "name": ref.stem, "ref": str(ref), "ref_secs": round(dur, 2)}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "reference decode timed out"}
    finally:
        try:
            os.remove(raw)
        except OSError:
            pass


@app.post("/voice/clone")
async def voice_clone(request: Request, name: str):
    """Register a cloned voice. Query param ?name=<name>; body = raw reference audio
    bytes (wav/webm/ogg). OPT-IN: only saves the reference here — the heavy XTTS model
    is not touched until the clone is actually spoken via voice='clone:<name>'."""
    if not cloning_available():
        return {"ok": False, "error": "cloning not installed (clone_env venv missing)"}
    try:
        audio = await request.body()
        if not audio:
            return {"ok": False, "error": "no reference audio received"}
        return await asyncio.to_thread(_register_clone, name, audio)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": str(e)}


@app.get("/clones")
async def clones():
    return {"clones": list_clones(), "cloning_available": cloning_available()}


@app.get("/health")
async def health():
    voices = list_voices()
    devices = list_devices()
    clones = list_clones()
    default_model = voice_path(DEFAULT_VOICE)
    return {
        "status": "ok" if default_model.exists() and voices else "degraded",
        "model": str(default_model),
        "model_present": default_model.exists(),
        "current_voice": DEFAULT_VOICE,
        "current_device": "default",
        "voice_count": len(voices),
        "device_count": len(devices),
        # STT (local whisper.cpp)
        "stt_available": stt_available(),
        "stt_model": str(WHISPER_MODEL),
        "stt_model_present": WHISPER_MODEL.exists(),
        # Voice cloning (XTTS-v2, opt-in, off-by-default — model loads on first use)
        "cloning_available": cloning_available(),
        "clone_count": len(clones),
    }


if __name__ == "__main__":
    # 8765 is taken by the existing beewid-mcp server; use a dedicated free port.
    uvicorn.run(app, host="127.0.0.1", port=8770, log_level="warning")
