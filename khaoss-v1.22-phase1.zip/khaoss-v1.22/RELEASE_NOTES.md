# KHAOSS v1.22 — release notes

A local-first multi-agent stack: the AionUi desktop app (team orchestration) + the Hermes agent
runtime + a CPU-only voice stack — with **privacy as the default** and a real **local-or-scrubbed-cloud
choice**.

> **Provably clean.** This package ships clean scaffolding + an installer that fetches/builds a clean
> source. It contains **no** keys, conversations, teams, or personal identifiers — verified by a
> 3-way privacy scan (`CLEAN_SCAN.log` / `CLEAN_SCAN_FINAL.log`, **0 hits**).

## What's new in v1.22

### 🔊 Voice
- **Auditory conversation layer** — replies are spoken (summary-first), with a clean per-message
  trigger (the "Also K" truncation bug is gone).
- **Per-message re-read** — every reply has a 🔊 button; tap any past message to hear it again.
- **STOP-voice** — a glowing red Stop appears while a read plays; tap it to halt mid-stream.
- **Concise-first + "Continue in detail"** — summaries by default; expand on demand (button + spoken
  "yes"). The spoken offer line is now a strengthened, exact prompt across models (button is the
  guaranteed fallback).
- Voice input (speech-to-text) for talking back.

### 🛡 Safety & reliability
- **Runaway-output guard** — a model repetition/degeneration collapse is cancelled at the **kilobyte**
  scale (not tens of MB), with a visible error + a persist cap + no post-cancel write loop.
- **Skip-permissions ladder** (Prompt all → Auto-approve safe → Skip) with an **always-on catastrophic
  denylist** that fires even in Skip — and never silently.
- **No silent failure** — swallowed HTTP 4xx (bad model id, usage cap) are captured + surfaced;
  **bounded retry-on-empty** + **session re-establish** recover transient drops; roster status
  self-heals (a responding agent is never "failed"; a quiet leader is idle).
- **Spawn-id validation** against the live model catalog — a bad/retired id is rejected at spawn with
  suggestions, not failed opaquely later.

### 🤖 Models & teams
- **Refresh AI options** — re-fetch the live catalog (cloud) + enumerate **local Ollama** models,
  merged + marked.
- **Leader-profile selection** at team creation.
- **4 ready-to-use example teams** — Personal Assistant · Research Pod · Build Squad · Debate Circle —
  real working roles, each with the privacy choice.

### 🔒 Privacy — your AI, your choice
- **Local AI (nothing leaves)** via a shipped `local` Ollama profile, **or** **privacy-scrubbed cloud**
  (an always-on regex redaction pass strips secrets/PII before any send). **Privacy is the default.**
- See **`PRIVACY_AND_AI_CHOICE.md`**. The control panel surfaces a **secret-keeper** status + Test.

## Install
```bash
./install.sh            # full install + voice self-verify
./scan_clean.sh         # verify clean (0 hits)
```
See `README.md`, `MANIFEST.md`, and the `*/SETUP.md` docs.

## Coming next (roadmap)
- **Voice-activated, tactile onboarding tutorial** — a guided first-run where you *talk* to the stack
  and it walks you through setup out loud (the same warm, voice-guided experience this was built with),
  with a coding-AI assist path for anyone who wants hands-on help wiring it up.
- SLM redaction wired into the live per-call scrub (today it's an on-demand enhancement; the regex is
  the live default).
- New Chat voice parity (voice/re-read/STOP are Teams-first today).

---
*KHAOSS v1.22 · local-first · privacy by default.*
