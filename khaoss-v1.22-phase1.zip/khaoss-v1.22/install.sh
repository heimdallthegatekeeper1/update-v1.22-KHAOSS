#!/usr/bin/env bash
# KHAOSS v1.22 — installer + self-verify (CPU-only friendly).
# Sets up the voice stack (piper TTS + whisper.cpp STT), scaffolds AionUi + Hermes setup, and
# SELF-VERIFIES: voicebox health, voice synth, transcribe. Voice CLONING (XTTS) is OPTIONAL/deferred.
#
# Usage:
#   ./install.sh              # full install + self-verify into ~/.khaoss
#   KHAOSS_HOME=/tmp/khaoss-test ./install.sh --voice-only   # fresh-location voice self-verify
#
# Safe to re-run. Never writes secrets; the operator supplies provider keys locally.
set -uo pipefail

KHAOSS_HOME="${KHAOSS_HOME:-$HOME/.khaoss}"
PIPER_DIR="${PIPER_DIR:-$HOME/.local/share/piper}"
WHISPER_DIR="${WHISPER_DIR:-$HOME/.local/share/whisper}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VOICE_ONLY=0; [ "${1:-}" = "--voice-only" ] && VOICE_ONLY=1
PASS=0; FAIL=0
ok(){ echo "  [PASS] $*"; PASS=$((PASS+1)); }
bad(){ echo "  [FAIL] $*"; FAIL=$((FAIL+1)); }
log(){ echo "==> $*"; }

log "KHAOSS v1.22 install → $KHAOSS_HOME (voice-only=$VOICE_ONLY)"
mkdir -p "$KHAOSS_HOME" "$PIPER_DIR" "$WHISPER_DIR"

# ── Voice deps (CPU-only) ───────────────────────────────────────────────
log "Setting up the voicebox venv (CPU-only)…"
if command -v python3 >/dev/null 2>&1; then
  python3 -m venv "$KHAOSS_HOME/voice-venv" 2>/dev/null || true
  # shellcheck disable=SC1091
  source "$KHAOSS_HOME/voice-venv/bin/activate" 2>/dev/null || true
  pip install -q --upgrade pip >/dev/null 2>&1 || true
  pip install -q -r "$HERE/voicebox/requirements.txt" >/dev/null 2>&1 \
    && ok "voicebox python deps installed" || bad "voicebox deps install (continuing; may need system piper)"
else
  bad "python3 not found — install Python 3.10+ first"
fi
cp -f "$HERE/voicebox/tts_server.py" "$KHAOSS_HOME/tts_server.py"

# ── Models (download if missing; CPU-only) ──────────────────────────────
log "Ensuring models (piper voice + whisper.cpp)…"
PIPER_ONNX="$PIPER_DIR/en_US-lessac-medium.onnx"
if [ ! -f "$PIPER_ONNX" ]; then
  curl -fsSL -o "$PIPER_ONNX" \
    "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/lessac/medium/en_US-lessac-medium.onnx" 2>/dev/null \
    && curl -fsSL -o "$PIPER_ONNX.json" \
    "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/lessac/medium/en_US-lessac-medium.onnx.json" 2>/dev/null \
    && ok "piper voice downloaded" || bad "piper voice download (check network)"
else ok "piper voice present"; fi
WHISPER_BIN_MODEL="$WHISPER_DIR/ggml-tiny.bin"
if [ ! -f "$WHISPER_BIN_MODEL" ]; then
  curl -fsSL -o "$WHISPER_BIN_MODEL" \
    "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.bin" 2>/dev/null \
    && ok "whisper model downloaded" || bad "whisper model download (check network)"
else ok "whisper model present"; fi

# ── Start voicebox + SELF-VERIFY (health, synth, transcribe) ────────────
log "Starting voicebox + self-verifying…"
PORT="${TTS_PORT:-8770}"
( python3 "$KHAOSS_HOME/tts_server.py" >"$KHAOSS_HOME/voicebox.log" 2>&1 & echo $! > "$KHAOSS_HOME/voicebox.pid" ) || true
for i in $(seq 1 20); do curl -fsS "http://127.0.0.1:$PORT/health" >/dev/null 2>&1 && break; sleep 0.5; done
if curl -fsS "http://127.0.0.1:$PORT/health" >/dev/null 2>&1; then
  ok "voicebox /health responding on :$PORT"
  SYNTH=$(curl -fsS -m 20 -X POST "http://127.0.0.1:$PORT/speak" -H 'Content-Type: application/json' \
    -d '{"text":"KHAOSS install self verification.","play":false}' 2>/dev/null || true)
  echo "$SYNTH" | grep -q '"ok":[[:space:]]*true' && ok "voice synth (TTS) works" || bad "voice synth"
  # transcribe round-trip if the synth produced a wav + /transcribe exists
  WAV=$(echo "$SYNTH" | sed -n 's/.*"output":[[:space:]]*"\([^"]*\)".*/\1/p')
  if [ -n "$WAV" ] && [ -f "$WAV" ]; then
    # /transcribe takes RAW audio bytes in the body (not multipart).
    TX=$(curl -fsS -m 30 -X POST "http://127.0.0.1:$PORT/transcribe" \
      -H 'Content-Type: application/octet-stream' --data-binary @"$WAV" 2>/dev/null || true)
    echo "$TX" | grep -qiE '"ok":[[:space:]]*true|khaoss|verification' && ok "transcribe (STT) works" || bad "transcribe (STT)"
  else
    echo "  [SKIP] transcribe — no wav produced (synth play=false path)"
  fi
else
  bad "voicebox did not start (see $KHAOSS_HOME/voicebox.log)"
fi

# ── AionUi + Hermes (scaffold only in Phase 1) ──────────────────────────
if [ "$VOICE_ONLY" -eq 0 ]; then
  log "AionUi + Hermes: see aionui/SETUP.md and hermes/SETUP.md (installer-fetched; not bundled)."
  [ -f "$HERE/aionui/SETUP.md" ] && ok "AionUi setup doc present" || bad "AionUi setup doc"
  [ -f "$HERE/hermes/SETUP.md" ] && ok "Hermes setup doc present" || bad "Hermes setup doc"

  # ── Local AI choice: install the 'local' Hermes profile (Ollama, nothing leaves) ─────────
  log "Installing the 'local' Hermes profile (for the Local-AI choice)…"
  LOCAL_PROFILE_SRC="$HERE/hermes/profiles/local/config.yaml"
  LOCAL_PROFILE_DST="$HOME/.hermes/profiles/local"
  if [ -f "$LOCAL_PROFILE_SRC" ]; then
    mkdir -p "$LOCAL_PROFILE_DST"
    cp -n "$LOCAL_PROFILE_SRC" "$LOCAL_PROFILE_DST/config.yaml" 2>/dev/null || true
    ok "'local' Hermes profile installed → ~/.hermes/profiles/local (Ollama, nothing leaves)"
  else
    bad "'local' profile template missing"
  fi
  # Self-check the local AI path: is Ollama reachable + does it have a model?
  if curl -fsS -m4 http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
    NMODELS=$(curl -fsS -m4 http://127.0.0.1:11434/api/tags 2>/dev/null | grep -o '"name"' | wc -l)
    ok "Local AI reachable — Ollama on :11434 with $NMODELS model(s). 'Local AI, nothing leaves' is ready."
  else
    echo "  [INFO] Ollama not running — install it + 'ollama pull qwen2.5:7b' to use the Local-AI choice (the scrubbed-cloud choice works without it)."
  fi

  log "Voice CLONING (XTTS) is OPTIONAL — run with KHAOSS_ENABLE_CLONE=1 to set up clone_env (heavy)."
fi

echo ""
log "Self-verify: $PASS passed, $FAIL failed."
[ "$FAIL" -eq 0 ] && { log "STACK SELF-VERIFY OK"; exit 0; } || { log "SELF-VERIFY had failures (see above)"; exit 1; }
