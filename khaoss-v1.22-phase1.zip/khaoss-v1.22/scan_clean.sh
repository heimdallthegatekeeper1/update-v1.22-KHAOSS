#!/usr/bin/env bash
# KHAOSS v1.22 — clean-scan. Scans the staged package for secret/private leaks and requires ZERO hits.
# Excludes itself + the scan log (which legitimately contain the search patterns).
# Exit 0 = clean (zero hits); exit 1 = leaks found.
set -uo pipefail
STAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SELF="$(basename "${BASH_SOURCE[0]}")"

# GENERIC leak patterns that must not appear in the shippable payload. This scanner SHIPS, so it
# names NO specific person/team/host — only generic shapes of secrets + private data. (The package
# author runs an additional local pass for their own identifiers; that pass is not shipped.)
PATTERNS=(
  'sk-[A-Za-z0-9_-]{18,}'                                  # LiteLLM / OpenAI-style virtual keys
  'sk-ant-[A-Za-z0-9_-]{8,}'                               # Anthropic keys
  '(api[_-]?key|secret|token|bearer)["'"'"'[:= ]+[A-Za-z0-9_-]{20,}'  # generic key=VALUE
  'xoxb-[A-Za-z0-9-]{10,}|ghp_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}'  # Slack / GitHub / AWS keys
  '/home/[a-z][a-z0-9_-]+/|/Users/[a-z][a-z0-9_-]+/'       # absolute personal home paths (any OS)
  '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'         # any email address
  'BEGIN (RSA|OPENSSH|EC|DSA|PRIVATE) KEY'                 # private keys
)

HITS=0
# Scan RELATIVE to the package dir so the OUTPUT never contains an absolute operator path
# (the scan log ships in the package — it must itself be clean). Exclude the meta/audit files.
cd "$STAGE" || exit 2
echo "KHAOSS clean-scan @ $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "Target: ./ (khaoss-v1.22 package)"
echo "Excluded from scan: $SELF, CLEAN_SCAN.log, CLEAN_SCAN_FINAL.log"
echo "----------------------------------------"
for pat in "${PATTERNS[@]}"; do
  # grep recursively (relative '.'), binary-skip, exclude the scanner + both audit logs
  matches="$(grep -rInE "$pat" . \
      --exclude="$SELF" --exclude="CLEAN_SCAN.log" --exclude="CLEAN_SCAN_FINAL.log" --binary-files=without-match 2>/dev/null || true)"
  if [ -n "$matches" ]; then
    n=$(printf '%s\n' "$matches" | grep -c .)
    echo "[HIT x$n] pattern: $pat"
    printf '%s\n' "$matches" | sed 's/^/    /' | head -10
    HITS=$((HITS+n))
  fi
done
echo "----------------------------------------"
if [ "$HITS" -eq 0 ]; then
  echo "RESULT: CLEAN — 0 hits. Package is provably free of the scanned secret/private patterns."
  exit 0
else
  echo "RESULT: $HITS HIT(S) — NOT CLEAN. Remove/scrub the files above before staging."
  exit 1
fi
