# KHAOSS v1.22 — Package Manifest (Phase 1, LOCAL stage — NOT published)

**Generated:** 2026-06-25 · **Phase:** 1 (inventory + clean + self-verify, staged local) · **Publish:** NO (gated on operator grand-verification)

This package is the **clean, shippable scaffolding** for the KHAOSS stack. Under the STRICT private-data
exclusion rule ("when in doubt, EXCLUDE"), the heavy app/runtime trees are **installer-fetched/built**
rather than bundled, so the staged package can be certified leak-free by the clean-scan.

---

## INCLUDED (shipped in this package)
| Path | What | Notes |
|---|---|---|
| `install.sh` | Installer + self-verify | CPU-only friendly; voice cloning optional/deferred; fresh-location capable (`--voice-only`, `KHAOSS_HOME=`) |
| `scan_clean.sh` | Clean-scan scanner | Scans the payload for secrets/private data; requires ZERO hits |
| `CLEAN_SCAN.log` | Clean-scan result | The recorded ZERO-hit scan output |
| `MANIFEST.md` | This file | Included vs excluded, for grand-verification |
| `README.md` | How to install + use | Generic, no operator data |
| `voicebox/tts_server.py` | TTS/STT server | Copied + verified clean (portable `~`/env paths only) |
| `voicebox/clone_worker.py` | Optional XTTS clone worker | Cloning is opt-in/deferred |
| `voicebox/hermes_voice_tool.yaml` | Voice tool descriptor | Generic |
| `voicebox/requirements.txt`, `voicebox/models.txt` | Deps + model fetch | Models downloaded by installer (not bundled) |
| `example-teams/*.json` | 4 generic example teams | Personal Assistant · Research Pod · Build Squad · Debate Circle (optional) — fresh, NO private data |
| `aionui/SETUP.md`, `hermes/SETUP.md` | Setup docs | How the installer fetches/builds the heavy components |

## EXCLUDED (HARD — never shipped; when in doubt, EXCLUDE)
| Category | Why excluded |
|---|---|
| **All of the operator's private teams** (finance/trading, research/science, bot, personal-assistant, and every test team) | Private team data + operator identity |
| **The operator's conversations / DB** (the AionUi config DB, message history, team records) | Private data — package ships with NO teams/conversations; created fresh on first run |
| **All secrets** — provider API keys, LiteLLM `sk-…`, OpenAI/Anthropic keys, every `.env` value, every `auth.json`, the credential pool | Secret material |
| **The operator's personal config / identifiers** — home paths, username/email/handles, operator-specific Hermes profiles (program leaders, numbered pools, per-model auto-profiles), the dev config dir | Operator identity |
| **AionUi heavy tree** — `node_modules`, `.git`, `out`, `resources/`, all `*.bak*` working artifacts | Non-shippable / risk of embedded operator data → installer fetches clean source + builds |
| **Hermes heavy tree** — the venv, all profiles, session DBs under the operator's home | Secrets + operator routing → installer installs fresh + creates a generic `general` profile |
| **Local models** — piper voice, whisper.cpp, XTTS clone env | Large; installer downloads them (CPU-only) |

---

## How the heavy components are handled (Phase 1)
- **AionUi:** `aionui/SETUP.md` — clean source fetched (no `node_modules`/`.git`/`out`/`resources`/`*.bak`),
  `npm install`, `npx electron-vite build`. Provider keys supplied locally by the operator.
- **Hermes:** `hermes/SETUP.md` — installed fresh; a generic `general` profile is created with no keys.
- **Models:** `voicebox/models.txt` — piper + whisper.cpp downloaded by `install.sh` (CPU-only).

## Grand-verification checklist (operator)
1. Read this manifest — confirm INCLUDED vs EXCLUDED matches intent.
2. Run `./scan_clean.sh` — confirm **0 hits** (also recorded in `CLEAN_SCAN.log`).
3. Run `./install.sh` (optionally in a fresh `KHAOSS_HOME`) — confirm the voice stack self-verifies.
4. Decide whether to bundle a built, re-scanned AionUi app for the public release (Phase 2).
5. ONLY THEN publish. **Phase 1 publishes nothing.**
