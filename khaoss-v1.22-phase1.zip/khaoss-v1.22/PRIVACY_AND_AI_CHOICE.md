# Your AI, your choice — privacy first

KHAOSS is built so **your data and your choices stay yours**. When you run the Personal Assistant
(or any team), you choose **how the AI runs**. Both options respect your privacy — pick the trade-off
you want.

## The choice (privacy is the default)

### 🖥 Local AI — nothing leaves your machine  *(maximum privacy)*
- Runs on a **local Ollama model** (e.g. `qwen2.5:7b`, `llama3.1:8b`). **No text is sent anywhere.**
- Needs Ollama running locally (the installer can set this up) + a few GB of RAM.
- Trade: most private; very capable for everyday help, not as strong as the largest cloud models.

### ☁ Privacy-scrubbed cloud — strongest models, scrubbed before it leaves
- Runs on a **cloud model** (via Mammouth — e.g. `kimi-k2.6`, `claude-sonnet-4-6`).
- **Before any text leaves the box, the deterministic regex scrub redacts** secrets, API keys,
  emails, paths, SSNs, and operator identifiers (Component A — **always on**). An on-box SLM
  recognizer (Component B) is an optional on-demand enhancement.
- Needs a Mammouth API key — **you supply it locally; it is never shipped**.
- Trade: strongest capability; text leaves **only after** the scrub redacts sensitive data — and
  **you** hold the key and control the scrub.

## How to choose
- **Default is privacy.** Out of the box, the scrub is live for anything cloud-bound; choosing
  **local** means nothing leaves at all.
- Pick the leader's model in the team's model selector. Run **"Refresh AI options"** to see your
  **local (Ollama) + cloud (Mammouth)** models side by side, each marked 🖥 local / ☁ cloud.
- Model ids are **validated against the live catalog** at spawn — a bad/retired id is rejected with
  suggestions, never silently broken.

## What we never do
- We never send your text to the cloud **without** the scrub (when you choose cloud) — and **never at
  all** when you choose local.
- We never ship your keys, conversations, teams, or identifiers. The package contains **none** of them.

## Verify it yourself
- The control panel (`:7842`) shows the **🔒 secret keeper** — the scrub status + a **Test** button
  that runs a sample so you can see redaction live.
- The package ships with a **clean-scan** (`./scan_clean.sh`) — run it; it must report **0 hits**.
