# Hermes agent runtime — setup

**Why it isn't bundled here (Phase 1):** the Hermes install (~2 GB) includes a Python venv and the
operator's **profiles** — every profile's `.env` holds secrets (the Mammouth LiteLLM `sk-…`, OpenAI/
Anthropic keys), and the profiles encode operator-specific routing, souls, and session DBs. Under the
STRICT exclusion rule, **none** of the operator's `~/.hermes` is bundled. The installer installs Hermes
fresh and creates a generic `general` profile; the operator supplies keys locally.

## What the installer does
1. Install Hermes into a fresh venv (`pip install hermes-agent`, or from the provided source).
2. Create a **generic** `general` profile (`~/.hermes/profiles/general/config.yaml`) — no keys baked in;
   `api_key` left empty / read from `key_env`.
3. Prompt the operator to drop their provider key into the profile `.env` (never shipped).

## Profiles
- The example teams reference the `general` profile (scrubbed-cloud). The operator can add more
  profiles — those are operator-created, never shipped.
- Model ids are validated against the live Mammouth catalog at spawn (see the AionUi changelog).

### `local` profile — for the "Local AI, nothing leaves" choice
- The package ships **`hermes/profiles/local/config.yaml`** — a clean profile pointing at a local
  Ollama server (`base_url: http://127.0.0.1:11434/v1`, no key). The installer copies it to
  `~/.hermes/profiles/local/config.yaml`.
- Pick a model you've pulled in Ollama (`ollama list`) and set it in the profile / the team's model
  selector (e.g. `qwen2.5:7b`, `llama3.1:8b`).
- The Personal Assistant team's **Local AI** choice uses `agentProfile: "local"` → the agent talks
  **only** to Ollama on 127.0.0.1. Nothing leaves the box. (This is why the choice needs the `local`
  profile, not `general` — `general` would route to the cloud.)

## Excluded (never shipped)
- All profile `.env` files, `auth.json`, session DBs, the credential pool, and every
  operator-specific profile (program leaders, numbered pools, per-model auto-profiles, …).
  Only the generic `general` profile is created fresh by the installer, with no keys baked in.
