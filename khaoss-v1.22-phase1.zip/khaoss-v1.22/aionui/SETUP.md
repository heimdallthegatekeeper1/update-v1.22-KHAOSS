# AionUi (KHAOSS fork) — setup

**Why it isn't bundled here (Phase 1):** the AionUi working tree carries `node_modules` (~2 GB),
`.git` (~0.5 GB), `resources/` (~0.7 GB) and operator working artifacts (`.bak` files, local config,
hardcoded paths). Under the STRICT private-data exclusion rule ("when in doubt, EXCLUDE"), the Phase-1
package does **not** bundle that tree — it would be impossible to certify as leak-free by inspection.
Instead the installer fetches a clean source and builds it. The operator's grand-verification decides
whether to bundle a built, scrubbed app.

## What the installer does
1. Clone/copy the AionUi fork **source only** (no `node_modules`, `.git`, `out`, `resources`, `*.bak*`,
   `*.env*`, `*.log`).
2. `npm install` (or `bun install`) to restore dependencies.
3. Build with **electron-vite** (NOT npm scripts that wrap something else):
   ```
   npx electron-vite build
   ```
4. Launch with `npm start` (or the packaged Electron binary).

## Config the operator supplies (never shipped)
- Provider API keys / `.env` (Mammouth LiteLLM `sk-…`, OpenAI/Anthropic, etc.) — entered locally.
- The app's config dir (conversations DB, teams) is created fresh on first run — the shipped package
  contains **no** conversations, teams, or DB.

## First run
- Create teams from `../example-teams/*.json` (generic seeds) — see the README.
- Pick the leader's Hermes profile at team creation (leader-profile selector).
