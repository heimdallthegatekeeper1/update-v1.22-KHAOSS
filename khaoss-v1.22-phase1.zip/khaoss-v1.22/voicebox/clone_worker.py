"""
XTTS-v2 clone worker — runs INSIDE clone_env (the heavy venv with torch+coqui-tts).

The main voicebox (system python, piper-only) talks to this worker over stdin/stdout
as a long-lived subprocess so the ~1.8GB XTTS model is loaded ONCE and stays warm,
instead of paying the ~11s model-load cost on every sentence.

Protocol (one JSON object per line on stdin -> one JSON object per line on stdout):
  -> {"cmd":"ping"}                                          <- {"ok":true,"ready":<bool>}
  -> {"cmd":"synth","ref":"<wav>","text":"...","out":"<wav>","language":"en","speed":1.0}
                                                             <- {"ok":true,"out":"...","secs":<f>}
On the FIRST synth the model is loaded lazily (opt-in / off-by-default): nothing heavy
happens until a clone is actually requested. All errors are returned as {"ok":false,"error":..}.
NO cloud — XTTS runs fully local on CPU.
"""
import sys
import os
import json
import time
import traceback

os.environ.setdefault("COQUI_TOS_AGREED", "1")  # accept XTTS license non-interactively (local use)

_TTS = None  # lazily loaded model handle


def _load_model():
    global _TTS
    if _TTS is not None:
        return _TTS
    from TTS.api import TTS  # heavy import, deferred until first clone synth
    model = TTS("tts_models/multilingual/multi-dataset/xtts_v2", progress_bar=False)
    try:
        model.to("cpu")
    except Exception:
        pass
    _TTS = model
    return _TTS


def _handle(req: dict) -> dict:
    cmd = req.get("cmd")
    if cmd == "ping":
        return {"ok": True, "ready": _TTS is not None}
    if cmd == "synth":
        ref = req["ref"]
        text = req["text"]
        out = req["out"]
        language = req.get("language", "en") or "en"
        speed = req.get("speed")
        if not os.path.exists(ref):
            return {"ok": False, "error": f"reference wav missing: {ref}"}
        model = _load_model()
        kwargs = dict(text=text, speaker_wav=ref, language=language, file_path=out)
        if speed is not None:
            try:
                kwargs["speed"] = float(speed)  # XTTS supports a speed multiplier
            except (TypeError, ValueError):
                pass
        t0 = time.time()
        model.tts_to_file(**kwargs)
        return {"ok": True, "out": out, "secs": round(time.time() - t0, 2)}
    return {"ok": False, "error": f"unknown cmd: {cmd}"}


def main():
    # Signal readiness for the import (not the model) so the parent knows the worker is alive.
    sys.stdout.write(json.dumps({"ok": True, "event": "started"}) + "\n")
    sys.stdout.flush()
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
            resp = _handle(req)
        except Exception as e:  # noqa: BLE001 - never crash the worker on one bad request
            resp = {"ok": False, "error": str(e), "trace": traceback.format_exc()[-500:]}
        sys.stdout.write(json.dumps(resp) + "\n")
        sys.stdout.flush()


if __name__ == "__main__":
    main()
